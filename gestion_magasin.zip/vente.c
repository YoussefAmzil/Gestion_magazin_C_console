#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "Lignecmd.c"

typedef struct Vente		
{
    int code ;
	Client *c; 
    char* date;
    LignecmdElement *lcmd;
    double total;
} Vente;
typedef struct VenteElement
{
    Vente* vente;
    struct VenteElement *next;
} VenteElement;


Vente * createvente (int code,LignecmdElement *l,char *d){
	Vente *v;
	v=(Vente*)malloc(sizeof(Vente));
	v->code=code;
	v->lcmd=l;
	v->date=(char*)malloc(strlen(d)*sizeof(char));
	v->total=0;
	return v;
}

void displayvente(Vente *c){
	if(c!=NULL) 
	{
		printf("code: %d - designation: %s - prix: %.2f \n\n");
	}
}

VenteElement *trouverFinvente(VenteElement *P)
{
    VenteElement *ptr;

    for(ptr=P; ptr->next!=NULL; ptr=ptr->next);

    return ptr;
}


void addventeToList(VenteElement **List , Vente *cl){
	
	if(*List==NULL){

		*List=(VenteElement*)malloc(sizeof(VenteElement));
		(*List)->vente=cl;
		(*List)->next=NULL;
		
	}
	else{
		VenteElement *new;
		new=(VenteElement*)malloc(sizeof(VenteElement));
		new->vente=cl;
		new->next=NULL;
		(trouverFinvente(*List))->next=new;
	
	}
	
}


