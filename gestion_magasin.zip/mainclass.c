#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "vente.c"

void gestionproduit(){
	int choix;
	char *des;
	Product *p1;
	ProductElement *l=NULL;
	menu:	printf("1-Ajouter un produit\n2-liste des produits\n0- quitter\n");
	scanf("%d",&choix);
	switch(choix){
		case 1:{
			p1=(Product*)malloc(sizeof(Product));
	repeat:	printf("donnez le code de produit  ");
			scanf("%d",&p1->code);
			printf("donnez la designation de produit  ");
			scanf("%s",des);
			p1->designation=(char*)malloc(strlen(des)*sizeof(char));
			strcpy(p1->designation,des);
			printf("donnez le prix de produit  ");
			scanf("%f",&p1->price);
			if(checkifexistpro(p1->code)){
				printf("le produit existe d�ja\n");
				goto repeat;
			}else{
				saveproducttodb(p1);
				printf("le produit est bien enregistrer\n");
				goto menu;
			}
		}break;
		case 2:{
			getproductfromdb(&l);
			diplayproductList(l);
			printf("\n");
			goto menu;
		};break;
		
	}
}

void gestionclient(){
	int choix;
	char *des;
	Client *c1;
	ClientElement *l=NULL;
	menu:	printf("1-Ajouter un client\n2-liste des clients\n0- quitter\n");
	scanf("%d",&choix);
	switch(choix){
		case 1:{
			c1=(Client*)malloc(sizeof(Client));
	repeat:	printf("donnez le code de client  ");
			scanf("%d",&c1->code);
			printf("donnez le nom de client  ");
			scanf("%s",des);
			c1->nom=(char*)malloc(strlen(des)*sizeof(char));
			strcpy(c1->nom,des);
			printf("donnez le prenom de client  ");
			scanf("%s",des);
			c1->prenom=(char*)malloc(strlen(des)*sizeof(char));
			strcpy(c1->prenom,des);
			printf("donnez le t�l�phone de client  ");
			scanf("%s",des);
			c1->tele =(char*)malloc(strlen(des)*sizeof(char));
			strcpy(c1->tele,des);
//			if(checkifexistpro(p1->code)){
//				printf("le produit existe d�ja\n");
//				goto repeat;
//			}else{
//				saveproducttodb(p1);
//				printf("le produit est bien enregistrer\n");
//				goto menu;
//			}
		}break;
		case 2:{
//			getproductfromdb(&l);
//			diplayproductList(l);
			printf("\n");
			goto menu;
		};break;
		
	}
}

void gestioncommande(){
	
}

int main(){
	int choix;
	Vente *v=NULL;
	LignecmdElement *lcmd=NULL;
	ProductElement *pe=NULL;

	do{
	printf("1-Gestion des produits\n2-Gestion des clients\n3-Gestion des commandes\n0- quitter\n");
	printf("Donnez votre choix :\n");
	scanf("%d",&choix);
		switch(choix){
		case 1: gestionproduit(); break;
		case 2: gestionclient() ;break;
		case 3:	gestioncommande() ;break;
	}
	}while(choix!=0);
	
	
	return 0;
}
