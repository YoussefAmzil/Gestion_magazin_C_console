#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *pf_out;
FILE *pf_in;
 
typedef struct Product		
{
    int code ; 
    char* designation;
    float price;
} Product;
typedef struct ProductElement
{
    Product* product;
    struct ProductElement *next;
} ProductElement;


Product * createproduit (int c,char *n,double t){
	Product *p;
	p=(Product*)malloc(sizeof(Product));
	p->code=c;
	p->price=t;

	p->designation=(char*)malloc(strlen(n)*sizeof(char));
	strcpy(p->designation,n);
	return p;
}

void displayproduit(Product *c){
	if(c!=NULL) 
	{
		printf("code: %d - designation: %s - prix: %.2f \n\n",(c)->code,c->designation,c->price);
	}
	else printf("le client est null ou n'existe pas");
}

ProductElement *trouverFinproduit(ProductElement *P)
{
    ProductElement *ptr;
    for(ptr=P; ptr->next!=NULL; ptr=ptr->next);

    return ptr;
}

void addProductToList(ProductElement **List , Product *cl){
	
	if(*List==NULL){

		*List=(ProductElement*)malloc(sizeof(ProductElement));
		(*List)->product=cl;
		(*List)->next=NULL;
		
	}
	else{
		ProductElement *new;
		new=(ProductElement*)malloc(sizeof(ProductElement));
		new->product=cl;
		new->next=NULL;
		(trouverFinproduit(*List))->next=new;
	
	}
	
}

void diplayproductList(ProductElement * L){

	while(L!=NULL){
		displayproduit(L->product);
		L=L->next;
	}
}

void getproductfromdb(ProductElement **pe){
	pf_in=fopen("produits.txt","r");
	Product *p;
	int y;
	p=(Product*)malloc(sizeof(Product));
	p->designation=(char*)malloc(30*sizeof(char));
	while (fscanf(pf_in,"%d %s %f\n",&p->code,p->designation,&p->price)!=EOF){
		addProductToList(pe,p);
		p=(Product*)malloc(sizeof(Product));
		p->designation=(char*)malloc(30*sizeof(char));
	}
	
}

int checkifexistpro(int code){
	Product *p;
	pf_in=fopen("produits.txt","r");
	p=(Product*)malloc(sizeof(Product));
	p->designation=(char*)malloc(30*sizeof(char));
		while (fscanf(pf_in,"%d %s %f\n",&p->code,p->designation,&p->price)!=EOF){
		if(p->code==code) return 1;
		}
	return 0;	
}


Product *getproduct(int c){
	ProductElement *o=NULL;
	getproductfromdb(&o);
	
	while(o!=NULL){
		if(o->product->code==c) break;	
				
		o=o->next;
	}
	return o->product;
}

void saveproducttodb(Product *p){
	pf_out=fopen("produits.txt","a");
	fprintf(pf_out,"%d %s %f\n",p->code,p->designation,p->price);
}


//int main()
//{
//    ProductElement *pe=NULL;
//	Product *p1,*p2;
//	p1=createproduit(123,"chipps",28.2);
//	p2=createproduit(1,"danoune",2.4);
////	saveproducttodb(p1);
////	saveproducttodb(p2);
//	getproductfromdb(&pe);
//	diplayproductList(pe);
//	//displayproduit(p1);
////	addProductToList(&pe,p1);
////	addProductToList(&pe,p2);
////	diplayproductList(pe);
//    return 0;
//}
