#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "client.c"
#include "produit.c"

typedef struct Lignecmd{
	int codeV;//code vente
	Product *p;
	int qte;
	float stotal;
}Lignecmd;

typedef struct LignecmdElement{
	Lignecmd *lcmd;
	struct LignecmdElement *next;
}LignecmdElement;


Lignecmd * createlcmd (int qte,int codev,Product *p){
	Lignecmd *c1;
	c1=(Lignecmd*)malloc(sizeof(Lignecmd));
	c1->qte=qte;
	c1->p=p;
	c1->stotal=qte*p->price;
	c1->codeV=codev;
	return c1;
}

LignecmdElement *trouverFin(LignecmdElement *L)
{
    LignecmdElement *ptr;

    for(ptr=L; ptr->next!=NULL; ptr=ptr->next);

    return ptr;
}

void addcmdToList(LignecmdElement **List , Lignecmd *cmd){
	
	if(*List==NULL){

		*List=(LignecmdElement*)malloc(sizeof(LignecmdElement));
		(*List)->lcmd=cmd;
		(*List)->next=NULL;
		
	}
	else{
		LignecmdElement *new;
		new=(LignecmdElement*)malloc(sizeof(LignecmdElement));
		new->lcmd=cmd;
		new->next=NULL;
		(trouverFin(*List))->next=new;
	
	}
}

void displaycmd(Lignecmd *c){
	if(c!=NULL) 
	{
		displayproduit(c->p);
		printf("quantite: %d - sous total: %2.f \n\n",c->qte,c->stotal);
	}
	else printf("la ligne commande est null ou n'existe pas");
}

void diplaycmdList(LignecmdElement * L){

	while(L!=NULL){
		displaycmd(L->lcmd);
		printf("\n---------------\n");
		L=L->next;
	}
}

double gettotal(LignecmdElement *L){
	double t=0;
	while(L!=NULL){
		t+=L->lcmd->stotal;
		L=L->next;
	}
}

void savelcmdtodb(Lignecmd *c){
	pf_out=fopen("lcmds.txt","a");
	fprintf(pf_out,"%d %d %d %f\n",c->codeV,c->p->code,c->qte,c->stotal);
}

void getlcmdfromdb(LignecmdElement **pe){
	pf_in=fopen("lcmds.txt","r");
	Lignecmd *p;
	p=(Lignecmd*)malloc(sizeof(Lignecmd));
	p->p=(Product*)malloc(sizeof(Product));
	while (fscanf(pf_in,"%d %d %d %f\n",&p->codeV,&p->p->code,&p->qte,&p->stotal)!=EOF){
		p->p=getproduct(p->p->code);
		addcmdToList(pe,p);
		p=(Lignecmd*)malloc(sizeof(Lignecmd));
		p->p=(Product*)malloc(sizeof(Product));
	}
}

//int main(){
//	Lignecmd *l1,*l2;
//	Product *p,*p2;
//	LignecmdElement *L=NULL;
//	p=createproduit(123,"chips",28.6);
//	p2=createproduit(1,"danone",2.6);
//	l1=createlcmd(2,3,p);
//	l2=createlcmd(1,9,p2);
//	savelcmdtodb(l1);
//	getlcmdfromdb(&L);
//	diplaycmdList(L);
//	return 0;
//}
